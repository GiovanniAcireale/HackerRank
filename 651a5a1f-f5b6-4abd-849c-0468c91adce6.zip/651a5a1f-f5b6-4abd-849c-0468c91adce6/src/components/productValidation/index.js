// components/productValidation/index.js

import React, { useState, useEffect } from "react";
import "./index.css";

function ProductValidation() {
  // State variables for input values
  const [name, setName] = useState("");
  const [quantity, setQuantity] = useState("");

  // State variables to track if inputs have been touched
  const [nameTouched, setNameTouched] = useState(false);
  const [quantityTouched, setQuantityTouched] = useState(false);

  // State variable to control submit button
  const [isFormValid, setIsFormValid] = useState(false);

  // Effect to validate form whenever input values change
  useEffect(() => {
    const isNameValid = name.trim() !== "";
    const isQuantityValid = quantity !== "" && Number(quantity) > 0;

    if (isNameValid && isQuantityValid) {
      setIsFormValid(true);
    } else {
      setIsFormValid(false);
    }
  }, [name, quantity]);

  // Handlers for name input
  const handleNameChange = (e) => {
    setNameTouched(true); // Set touched on any input event
    setName(e.target.value);
  };

  // Handlers for quantity input
  const handleQuantityChange = (e) => {
    setQuantityTouched(true); // Set touched on any input event
    setQuantity(e.target.value);
  };

  // Handler for form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform submission logic here (e.g., send data to backend)
    alert(`Product Submitted:\nName: ${name}\nQuantity: ${quantity}`);
    // Reset form after submission if needed
    setName("");
    setQuantity("");
    setNameTouched(false);
    setQuantityTouched(false);
  };

  // Validation checks
  const isNameValid = name.trim() !== "";
  const isQuantityValid = quantity !== "" && Number(quantity) > 0;

  return (
    <div className="layout-column justify-contents-center align-items-center">
      <section className="card pa-50">
        <form className="layout-column" noValidate onSubmit={handleSubmit}>
          {/* Product Name Input Group */}
          <div className="form-group">
            <input
              type="text"
              value={name}
              onInput={handleNameChange} // Changed from onChange to onInput
              data-testid="name-input"
              className="white large outlined"
              placeholder="Product name"
            />
            {/* Error Message for Product Name */}
            {!isNameValid && nameTouched && (
              <p
                className="error-text form-hint"
                data-testid="name-input-error"
              >
                Product name is required
              </p>
            )}
          </div>

          {/* Quantity Input Group */}
          <div className="form-group">
            <input
              type="number"
              value={quantity}
              onInput={handleQuantityChange} // Changed from onChange to onInput
              data-testid="quantity-input"
              className="white large outlined"
              placeholder="Quantity"
            />
            {/* Error Message for Quantity */}
            {!isQuantityValid && quantityTouched && (
              <p
                className="error-text form-hint"
                data-testid="quantity-input-error"
              >
                Quantity is required
              </p>
            )}
          </div>

          {/* Submit Button */}
          <button
            className="mt-50"
            type="submit"
            data-testid="submit-button"
            disabled={!isFormValid}
          >
            Submit
          </button>
        </form>
      </section>
    </div>
  );
}

export default ProductValidation;
